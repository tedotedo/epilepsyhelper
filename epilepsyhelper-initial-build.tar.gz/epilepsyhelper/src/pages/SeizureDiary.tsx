import { Link } from 'react-router-dom';
import { Calendar, Plus } from 'lucide-react';

const SeizureDiary = () => {
  return (
    <div className="space-y-6">
      <header className="page-header">
        <Link to="/" className="back-link">
          ← Back to Home
        </Link>
        <div className="flex items-center gap-3">
          <Calendar className="w-8 h-8 text-primary-600" />
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-warm-800">
              Seizure Diary
            </h1>
            <p className="text-sm text-warm-500">Track and manage seizure events</p>
          </div>
        </div>
      </header>

      <div className="card p-8 text-center">
        <Calendar className="w-16 h-16 mx-auto text-warm-300 mb-4" />
        <h2 className="text-xl font-bold text-warm-900 mb-2">Coming Soon</h2>
        <p className="text-warm-600 mb-6">
          The seizure diary feature is currently under development. You'll be able to log seizures, track patterns, and export reports.
        </p>
        <button className="btn-primary inline-flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Log Seizure (Preview)
        </button>
      </div>
    </div>
  );
};

export default SeizureDiary;
